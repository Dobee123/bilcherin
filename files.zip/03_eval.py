#!/usr/bin/env python3
"""
판정 모델 평가 + 스키마 강제 디코딩.

핵심 두 가지를 본다.
  1) 형식 — guided decoding을 켜면 JSON 유효율이 구조적으로 100%가 된다.
     그래서 형식은 측정 대상이 아니라 보장 대상이다. 끄고도 재보면
     파인튜닝이 형식을 얼마나 익혔는지 알 수 있다.
  2) 내용 — 플래그 정확도. 이게 진짜 성능이다.
     특히 플래그별 false->true 전환 정확도를 따로 봐야 한다.
     대부분의 샘플이 "변화 없음"이라 전체 정확도는 쉽게 높아 보인다.

  python 03_eval.py --adapter out/judge-lora                  # vLLM, 스키마 강제
  python 03_eval.py --adapter out/judge-lora --no-guided      # 강제 없이
  python 03_eval.py --adapter out/judge-lora --backend hf     # GPU 작을 때
"""

from __future__ import annotations
import argparse, json
from collections import Counter
from pathlib import Path

import spec


def load_test(adapter: str, path: str | None) -> list[dict]:
    p = Path(path) if path else Path(adapter) / "test.jsonl"
    if not p.exists():
        raise SystemExit(f"평가 데이터가 없습니다: {p}  (02_train.py가 만듭니다)")
    return [json.loads(l) for l in open(p, encoding="utf-8")]


def run_vllm(rows, base, adapter, guided, max_tokens):
    from vllm import LLM, SamplingParams
    from vllm.lora.request import LoRARequest

    llm = LLM(model=base, enable_lora=True, max_lora_rank=64,
              max_model_len=2048, gpu_memory_utilization=0.85,
              trust_remote_code=True)
    tok = llm.get_tokenizer()

    kw = {"temperature": 0.0, "max_tokens": max_tokens}
    if guided:
        # 스키마 밖의 토큰은 디코딩 단계에서 아예 막힌다.
        try:
            from vllm.sampling_params import GuidedDecodingParams
            kw["guided_decoding"] = GuidedDecodingParams(json=spec.OUTPUT_SCHEMA)
        except ImportError:
            print("[주의] 이 vLLM 버전에서 guided decoding을 찾지 못했습니다. 끄고 진행합니다.")

    prompts = [
        tok.apply_chat_template(
            [{"role": "user", "content": spec.build_prompt(
                r["state"], r.get("history", []), r["action"])}],
            tokenize=False, add_generation_prompt=True)
        for r in rows
    ]
    outs = llm.generate(prompts, SamplingParams(**kw),
                        lora_request=LoRARequest("judge", 1, adapter))
    return [o.outputs[0].text.strip() for o in outs]


def run_hf(rows, base, adapter, max_tokens):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    from peft import PeftModel

    tok = AutoTokenizer.from_pretrained(adapter, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        base,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16),
        dtype=torch.bfloat16, device_map={"": 0}, trust_remote_code=True)
    model = PeftModel.from_pretrained(model, adapter).eval()

    texts = []
    for i, r in enumerate(rows, 1):
        ids = tok.apply_chat_template(
            [{"role": "user", "content": spec.build_prompt(
                r["state"], r.get("history", []), r["action"])}],
            tokenize=True, add_generation_prompt=True, return_tensors="pt").to(model.device)
        with torch.no_grad():
            out = model.generate(ids, max_new_tokens=max_tokens, do_sample=False,
                                 pad_token_id=tok.pad_token_id or tok.eos_token_id)
        texts.append(tok.decode(out[0][ids.shape[-1]:], skip_special_tokens=True).strip())
        if i % 20 == 0:
            print(f"  {i}/{len(rows)}")
    return texts


def parse(text: str):
    try:
        return json.loads(text[text.index("{"): text.rindex("}") + 1])
    except (ValueError, json.JSONDecodeError):
        return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", required=True)
    ap.add_argument("--base", default="kakaocorp/kanana-nano-2.1b-instruct")
    ap.add_argument("--test", default=None)
    ap.add_argument("--backend", choices=["vllm", "hf"], default="vllm")
    ap.add_argument("--no-guided", action="store_true")
    ap.add_argument("--max-tokens", type=int, default=160)
    args = ap.parse_args()

    rows = load_test(args.adapter, args.test)
    print(f"평가 {len(rows)}건 · backend={args.backend} · "
          f"guided={'off' if args.no_guided else 'on'}\n")

    if args.backend == "vllm":
        texts = run_vllm(rows, args.base, args.adapter,
                         not args.no_guided, args.max_tokens)
    else:
        texts = run_hf(rows, args.base, args.adapter, args.max_tokens)

    n = len(rows)
    valid = exact = delta_ok = 0
    flag_total = Counter()      # 플래그별 전체
    flag_hit = Counter()        # 플래그별 적중
    flip_total = Counter()      # false->true 여야 하는 건
    flip_hit = Counter()
    misses = []

    for r, t in zip(rows, texts):
        gold = r["label"]
        got = parse(t)
        if got is None or not spec.validate(got):
            misses.append((r, t, "형식"))
            continue
        valid += 1

        ok_flags = True
        for f in spec.FLAGS:
            flag_total[f] += 1
            if got["set"][f] == gold["set"][f]:
                flag_hit[f] += 1
            else:
                ok_flags = False
            # 전환이 일어나야 하는 샘플만 따로 집계
            if gold["set"][f] and not r["state"]["flags"][f]:
                flip_total[f] += 1
                if got["set"][f]:
                    flip_hit[f] += 1

        ok_delta = got["trustDelta"] == gold["trustDelta"]
        delta_ok += ok_delta
        if ok_flags and ok_delta:
            exact += 1
        elif len(misses) < 12:
            misses.append((r, t, "내용"))

    print("=" * 56)
    print(f"JSON 유효율      {valid}/{n}  ({valid/n*100:.1f}%)")
    print(f"완전 일치        {exact}/{n}  ({exact/n*100:.1f}%)")
    print(f"trustDelta 일치  {delta_ok}/{n}  ({delta_ok/n*100:.1f}%)")
    print("-" * 56)
    print("플래그별 정확도")
    for f in spec.FLAGS:
        a = flag_hit[f] / flag_total[f] * 100 if flag_total[f] else 0
        print(f"  {f}  전체 {a:5.1f}%", end="")
        if flip_total[f]:
            b = flip_hit[f] / flip_total[f] * 100
            print(f"   false->true {b:5.1f}%  (n={flip_total[f]})")
        else:
            print("   false->true 샘플 없음")
    print("=" * 56)
    print("\n전체 정확도는 '변화 없음' 샘플 때문에 쉽게 높아 보입니다."
          "\nfalse->true 열이 실제 판정 능력입니다. 이쪽이 낮으면 해당 유형의 데이터를 늘리세요.\n")

    if misses:
        print("틀린 사례 (최대 12건)")
        for r, t, why in misses[:12]:
            print(f"\n[{why}] 단계={r['state']['phase']} 유형={r['kind']}")
            print(f"  행동: {r['action'][:70]}")
            print(f"  정답: {spec.build_target(r['label'])}")
            print(f"  출력: {t[:140]}")


if __name__ == "__main__":
    main()
