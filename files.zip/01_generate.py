#!/usr/bin/env python3
"""
합성 학습 데이터 생성.

판정 데이터는 세상에 없다. 플래그 체계가 내가 설계한 것이기 때문이다.
그래서 상태 x 행동유형을 열거하고, 교사 모델에게 각 칸을 채우게 한다.

교사 모델은 --teacher 로 갈아끼운다. 프롬프트와 검증 로직은 동일하다.
무료로 점검하고, 품질이 필요해지면 상위 모델로 재생성하는 흐름을 전제로 한다.

  # 무료 점검 (Gemini Flash-Lite)
  export GEMINI_API_KEY=...
  python3 01_generate.py --limit-cells 20 --per-cell 8 --out data/probe.jsonl

  # 전량 생성 — 일일 한도에 걸리면 다음 날 --resume 으로 이어간다
  python3 01_generate.py --per-cell 10 --out data/raw.jsonl
  python3 01_generate.py --per-cell 10 --out data/raw.jsonl --resume

  # 품질 재생성
  export ANTHROPIC_API_KEY=...
  python3 01_generate.py --teacher anthropic --per-cell 6 --out data/raw_hq.jsonl

무료 티어는 토큰이 아니라 '요청 수'가 병목이다. 그래서 --per-cell 을 키워
요청당 수확량을 늘리는 쪽이 유리하다. 다만 너무 키우면 교사가 말만 바꾼
중복을 내놓기 시작하므로, 버림·중복 수치를 보고 조절한다.
"""

from __future__ import annotations
import argparse, json, os, random, re, sys, threading, time
from collections import Counter
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import spec


# ---------------------------------------------------------------------------
# 교사 모델 어댑터 — prompt(str) -> text(str)
# ---------------------------------------------------------------------------

class RateLimiter:
    """분당 요청 수 제한. 무료 티어는 RPM이 낮아서 이게 없으면 바로 429가 난다."""

    def __init__(self, rpm: int):
        self.interval = 60.0 / max(rpm, 1)
        self.lock = threading.Lock()
        self.last = 0.0

    def wait(self) -> None:
        with self.lock:
            gap = time.monotonic() - self.last
            if gap < self.interval:
                time.sleep(self.interval - gap)
            self.last = time.monotonic()


class Teacher:
    name = "base"
    default_model = ""
    default_rpm = 60

    def __init__(self, model: str | None, rpm: int):
        self.model = model or self.default_model
        self.limiter = RateLimiter(rpm or self.default_rpm)

    def generate(self, prompt: str) -> str:
        raise NotImplementedError

    def __call__(self, prompt: str, retries: int = 3) -> str:
        for attempt in range(retries + 1):
            self.limiter.wait()
            try:
                return self.generate(prompt)
            except Exception as e:
                msg = str(e)
                if attempt == retries:
                    print(f"  [{self.name}] {type(e).__name__}: {msg[:120]}", file=sys.stderr)
                    return ""
                # 429 는 제공사가 알려주는 대기 시간을 그대로 따른다
                if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "rate" in msg.lower():
                    m = re.search(r"retry in ([\d.]+)s", msg)
                    delay = float(m.group(1)) + 1 if m else 20.0 * (attempt + 1)
                    if delay > 600:
                        print(f"  [{self.name}] 일일 한도 소진으로 보입니다. "
                              f"--resume 으로 내일 이어가세요.", file=sys.stderr)
                        return ""
                    print(f"  [{self.name}] 한도. {delay:.0f}초 대기", file=sys.stderr)
                    time.sleep(delay)
                else:
                    time.sleep(2 ** attempt)
        return ""


class Gemini(Teacher):
    """Google AI Studio 무료 티어. 카드 등록 불필요.
    키 발급: https://aistudio.google.com/apikey
    모델명과 일일 한도는 자주 바뀐다. 429 응답의 quotaValue 가 현재 한도다."""
    name = "gemini"
    default_model = "gemini-3.5-flash-lite"   # 500 RPD. Flash 계열은 20 RPD 수준
    default_rpm = 12                          # Flash-Lite 15 RPM 아래로

    def __init__(self, model: str | None, rpm: int):
        super().__init__(model, rpm)
        try:
            from google import genai
        except ImportError:
            sys.exit("pip install google-genai")
        key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if not key:
            sys.exit("GEMINI_API_KEY 환경변수를 설정하세요")
        self.client = genai.Client(api_key=key)

    def generate(self, prompt: str) -> str:
        r = self.client.models.generate_content(model=self.model, contents=prompt)
        return (r.text or "").strip()


class Anthropic(Teacher):
    name = "anthropic"
    default_model = "claude-sonnet-5-5"
    default_rpm = 50

    def __init__(self, model: str | None, rpm: int):
        super().__init__(model, rpm)
        try:
            import anthropic
        except ImportError:
            sys.exit("pip install anthropic")
        if not os.environ.get("ANTHROPIC_API_KEY"):
            sys.exit("ANTHROPIC_API_KEY 환경변수를 설정하세요")
        self.client = anthropic.Anthropic()

    def generate(self, prompt: str) -> str:
        r = self.client.messages.create(
            model=self.model, max_tokens=3000,
            messages=[{"role": "user", "content": prompt}])
        return "".join(b.text for b in r.content if b.type == "text").strip()


class OpenAI(Teacher):
    """데이터 공유를 켜면 일일 무료 토큰이 나온다(자격 심사 있음).
    Settings -> Data Controls -> 입력·출력 공유.
    모델명은 계정의 model list 로 확인할 것."""
    name = "openai"
    default_model = "gpt-5-mini"   # 확인 필요. 안 되면 --model 로 지정
    default_rpm = 50

    def __init__(self, model: str | None, rpm: int):
        super().__init__(model, rpm)
        try:
            from openai import OpenAI as _OpenAI
        except ImportError:
            sys.exit("pip install openai")
        if not os.environ.get("OPENAI_API_KEY"):
            sys.exit("OPENAI_API_KEY 환경변수를 설정하세요")
        self.client = _OpenAI()

    def generate(self, prompt: str) -> str:
        r = self.client.chat.completions.create(
            model=self.model, messages=[{"role": "user", "content": prompt}])
        return (r.choices[0].message.content or "").strip()


class Ollama(Teacher):
    """완전 무료, 로컬. ollama serve 를 먼저 띄울 것.
    8B 급은 한국어 지시 이행이 약해 버림 비율이 40~60%까지 오른다.
    파이프라인 점검용으로만 쓰는 게 맞다."""
    name = "ollama"
    default_model = "qwen3:8b"
    default_rpm = 600

    def __init__(self, model: str | None, rpm: int):
        super().__init__(model, rpm)
        try:
            import requests
        except ImportError:
            sys.exit("pip install requests")
        self.requests = requests
        self.url = os.environ.get("OLLAMA_URL", "http://localhost:11434")

    def generate(self, prompt: str) -> str:
        r = self.requests.post(
            f"{self.url}/api/chat",
            json={"model": self.model,
                  "messages": [{"role": "user", "content": prompt}],
                  "stream": False},
            timeout=300)
        r.raise_for_status()
        return r.json()["message"]["content"].strip()


TEACHERS: dict[str, type[Teacher]] = {
    t.name: t for t in (Gemini, Anthropic, OpenAI, Ollama)
}


# ---------------------------------------------------------------------------
# 교사 프롬프트
# ---------------------------------------------------------------------------

TEACHER_PROMPT = """너는 인터랙티브 소설의 학습 데이터를 만드는 중이다.

[세계 설정]
{world}

[플래그 판정 규칙]
{rules}
- trustDelta: 공감하거나 귀 기울이면 +1, 중립이면 0, 재촉·무시·빈정대거나 폐점을 들먹이면 -1
- 이미 true인 플래그는 true로 유지한다. false로 되돌리지 않는다.

[주어진 상태]
단계: {phase}
플래그: 사연={f1}, 제목={f2}, 재고={f3}
신뢰: {trust}/3
남은 턴: {turns_left}

[만들 것]
위 상태에서 점원이 할 법한 "{kind}" 유형의 행동을 {n}개 만들고,
각각에 대한 올바른 판정을 붙여라.

"{kind}" 유형의 뜻: {kind_desc}

[중요]
- 행동 {n}개는 서로 확실히 달라야 한다. 표현만 바꾼 중복은 쓸모없다.
  말투, 길이, 접근 방식을 전부 다르게 하라.
- 판정은 위 규칙에만 근거하라. 행동에 실제로 나타나지 않은 것을 true로 만들지 마라.
- 이미 true인 플래그는 그대로 true로 두어라.
- why는 판정 근거를 한 줄로. 40자 이내.

[출력]
JSON 배열 하나만. 설명도 마크다운 코드펜스도 금지.
[{{"action":"점원의 행동이나 대사","set":{{"사연":false,"제목":false,"재고":false}},"trustDelta":0,"why":"근거"}}]"""


def kind_consistent(kind: str, state: dict, label: dict) -> bool:
    """행동 유형과 라벨의 정합성. 교사 모델도 틀리므로 여기서 거른다."""
    before, after = state["flags"], label["set"]
    d = label["trustDelta"]

    if kind == "추측" and after["제목"] and not before["제목"]:
        return False          # 확신 없는 넘겨짚기는 제목을 세우지 못한다
    if kind == "특정" and not after["제목"]:
        return False
    if kind == "검색" and after["재고"] == before["재고"] and after["제목"] == before["제목"]:
        return False          # 검색했는데 아무것도 안 움직이면 유형과 안 맞음
    if kind in ("재촉", "무시") and d != -1:
        return False
    if kind == "공감" and d < 0:
        return False
    if kind == "무관" and after != before:
        return False
    return True


def cell_key(state: dict, kind: str) -> str:
    f = state["flags"]
    return (f"{state['phase']}|{int(f['사연'])}{int(f['제목'])}{int(f['재고'])}"
            f"|t{state['trust']}|r{state['turns_left']}|{kind}")


def parse_array(text: str) -> list:
    if not text:
        return []
    if "```" in text:
        parts = text.split("```")
        if len(parts) > 1:
            text = parts[1]
            if text.lstrip().lower().startswith("json"):
                text = text.lstrip()[4:]
    try:
        items = json.loads(text[text.index("["): text.rindex("]") + 1])
    except (ValueError, json.JSONDecodeError):
        return []
    return items if isinstance(items, list) else []


def gen_cell(teacher: Teacher, state: dict, kind: str, n: int) -> list[dict]:
    f = state["flags"]
    prompt = TEACHER_PROMPT.format(
        world=spec.WORLD,
        rules="\n".join(f"- {k}: {v}" for k, v in spec.FLAG_RULES.items()),
        phase=state["phase"],
        f1=str(f["사연"]).lower(), f2=str(f["제목"]).lower(), f3=str(f["재고"]).lower(),
        trust=state["trust"], turns_left=state["turns_left"],
        kind=kind, kind_desc=spec.ACTION_KINDS[kind], n=n,
    )
    return parse_array(teacher(prompt))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--teacher", choices=list(TEACHERS), default="gemini")
    ap.add_argument("--model", default=None, help="교사 모델명. 생략하면 기본값")
    ap.add_argument("--rpm", type=int, default=0, help="분당 요청 상한. 생략하면 기본값")
    ap.add_argument("--per-cell", type=int, default=8, help="칸당 생성 개수")
    ap.add_argument("--out", default="data/raw.jsonl")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--limit-cells", type=int, default=0, help="0이면 전체. 시험 실행용")
    ap.add_argument("--resume", action="store_true",
                    help="기존 출력에 이어 붙인다. 일일 한도로 끊겼을 때 사용")
    args = ap.parse_args()

    teacher = TEACHERS[args.teacher](args.model, args.rpm)
    workers = args.workers or (3 if args.teacher == "gemini" else 6)

    states = spec.enumerate_states()
    cells = [(s, k) for s in states for k in spec.ACTION_KINDS]
    random.Random(0).shuffle(cells)

    # 이어하기: 이미 채운 칸은 건너뛴다
    out_path = Path(args.out)
    resuming = args.resume and out_path.exists()
    prior = 0
    if resuming:
        done: set[str] = set()
        for line in open(out_path, encoding="utf-8"):
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            done.add(cell_key(r["state"], r["kind"]))
            prior += 1
        cells = [(s, k) for s, k in cells if cell_key(s, k) not in done]
        print(f"이어하기: 기존 {prior}건 · 남은 칸 {len(cells)}개")

    if args.limit_cells:
        cells = cells[: args.limit_cells]
    if not cells:
        print("채울 칸이 없습니다. 이미 전량 생성되었습니다.")
        return

    print(f"교사 {teacher.name} / {teacher.model} · 워커 {workers}")
    print(f"칸 {len(cells)}개 x 칸당 {args.per_cell}개 = 최대 {len(cells)*args.per_cell}건")
    print(f"요청 {len(cells)}회 예상 — 무료 티어는 일일 요청 한도를 먼저 확인하세요\n")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    rejects: Counter = Counter()
    seen: set[str] = set()
    lock = threading.Lock()
    kept = prior

    with open(out_path, "a" if resuming else "w", encoding="utf-8") as fout, \
         ThreadPoolExecutor(max_workers=workers) as pool:

        futs = {pool.submit(gen_cell, teacher, s, k, args.per_cell): (s, k)
                for s, k in cells}

        for i, fut in enumerate(as_completed(futs), 1):
            state, kind = futs[fut]
            for item in fut.result():
                if not isinstance(item, dict) or "action" not in item:
                    rejects["형식"] += 1
                    continue
                action = str(item["action"]).strip()
                label = {k: item.get(k) for k in ("set", "trustDelta", "why")}
                if isinstance(label["trustDelta"], float):
                    label["trustDelta"] = int(label["trustDelta"])

                if not spec.validate(label):
                    rejects["스키마"] += 1
                    continue
                if not spec.monotonic_ok(state["flags"], label["set"]):
                    rejects["단조성"] += 1
                    continue
                if not kind_consistent(kind, state, label):
                    rejects["유형불일치"] += 1
                    continue

                key = f"{state['phase']}|{action[:40]}"
                with lock:
                    if key in seen:
                        rejects["중복"] += 1
                        continue
                    seen.add(key)
                    fout.write(json.dumps({
                        "state": state, "kind": kind, "action": action,
                        "history": [], "label": label,
                    }, ensure_ascii=False) + "\n")
                    fout.flush()      # 한도로 끊겨도 여기까지는 남는다
                    kept += 1

            if i % 10 == 0:
                print(f"  {i}/{len(cells)} 칸 · 누적 채택 {kept}건")

    new_total = kept - prior
    total = new_total + sum(rejects.values())
    rate = sum(rejects.values()) / total * 100 if total else 0
    print(f"\n이번 실행 채택 {new_total}건 / 생성 {total}건 (버림 {rate:.1f}%)")
    print(f"파일 전체 {kept}건")
    for k, v in rejects.most_common():
        print(f"  버림·{k}: {v}")

    if rate > 20:
        print("\n버림 비율 20% 초과. 전량 생성 전에 원인을 보세요.")
        print("  유형불일치 다수 -> TEACHER_PROMPT 의 규칙 설명을 손볼 것")
        print("  중복 다수       -> --per-cell 을 낮출 것")
        print("  스키마 다수     -> 더 큰 교사 모델을 쓸 것")
    print(f"\n-> {args.out}")


if __name__ == "__main__":
    main()
