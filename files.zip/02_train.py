#!/usr/bin/env python3
"""
Kanana 2.1B QLoRA 파인튜닝.

trl 대신 plain transformers Trainer를 쓴다. 버전 churn에 덜 부서지고,
무엇보다 "프롬프트 구간은 loss에서 빼고 응답 구간만 학습한다"는
핵심 동작이 코드에 그대로 드러난다. 이걸 빼먹으면 모델이 프롬프트를
외우기 시작하고 판정 성능이 안 오른다.

  python 02_train.py --data data/raw.jsonl --out out/judge-lora

RTX 4090 24GB 또는 A10G로 충분. 3천 건 x 3epoch 기준 30~60분.
"""

from __future__ import annotations
import argparse, json, random
from dataclasses import dataclass
from pathlib import Path

import torch
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig,
    Trainer, TrainingArguments,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

import spec

# Hugging Face 저장소 id. 받기 전에 실제 id를 확인할 것.
# 후보: kakaocorp/kanana-nano-2.1b-instruct, kakaocorp/kanana-1.5-2.1b-instruct
DEFAULT_MODEL = "kakaocorp/kanana-nano-2.1b-instruct"

MAX_LEN = 1536


class JudgeDataset(Dataset):
    """프롬프트는 마스킹하고 JSON 응답만 학습 대상으로 삼는다."""

    def __init__(self, rows: list[dict], tok):
        self.rows, self.tok = rows, tok

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, i: int) -> dict:
        r = self.rows[i]
        user = spec.build_prompt(r["state"], r.get("history", []), r["action"])
        target = spec.build_target(r["label"])

        prompt_ids = self.tok.apply_chat_template(
            [{"role": "user", "content": user}],
            tokenize=True, add_generation_prompt=True,
        )
        target_ids = self.tok(target, add_special_tokens=False)["input_ids"]
        if self.tok.eos_token_id is not None:
            target_ids = target_ids + [self.tok.eos_token_id]

        ids = (prompt_ids + target_ids)[:MAX_LEN]
        # -100 은 loss에서 무시된다. 프롬프트 전체를 가린다.
        labels = ([-100] * len(prompt_ids) + target_ids)[:MAX_LEN]
        return {"input_ids": ids, "labels": labels}


@dataclass
class PadCollator:
    pad_id: int

    def __call__(self, feats: list[dict]) -> dict:
        n = max(len(f["input_ids"]) for f in feats)
        out = {"input_ids": [], "labels": [], "attention_mask": []}
        for f in feats:
            k = n - len(f["input_ids"])
            out["input_ids"].append(f["input_ids"] + [self.pad_id] * k)
            out["labels"].append(f["labels"] + [-100] * k)
            out["attention_mask"].append([1] * len(f["input_ids"]) + [0] * k)
        return {k: torch.tensor(v, dtype=torch.long) for k, v in out.items()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/raw.jsonl")
    ap.add_argument("--model", default=DEFAULT_MODEL)
    ap.add_argument("--out", default="out/judge-lora")
    ap.add_argument("--epochs", type=float, default=3.0)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--accum", type=int, default=4)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--test-frac", type=float, default=0.1)
    args = ap.parse_args()

    rows = [json.loads(l) for l in open(args.data, encoding="utf-8")]
    random.Random(42).shuffle(rows)
    cut = int(len(rows) * (1 - args.test_frac))
    train_rows, test_rows = rows[:cut], rows[cut:]

    # 평가용 split은 파일로 떼어둔다. 03_eval.py가 이걸 읽는다.
    Path(args.out).mkdir(parents=True, exist_ok=True)
    with open(Path(args.out) / "test.jsonl", "w", encoding="utf-8") as f:
        for r in test_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"학습 {len(train_rows)}건 / 평가 {len(test_rows)}건")

    tok = AutoTokenizer.from_pretrained(args.model, trust_remote_code=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        quantization_config=BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        ),
        dtype=torch.bfloat16,
        device_map={"": 0},
        trust_remote_code=True,
    )
    model.config.use_cache = False
    model = prepare_model_for_kbit_training(model)
    model = get_peft_model(model, LoraConfig(
        r=args.rank,
        lora_alpha=args.rank * 2,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
    ))
    model.print_trainable_parameters()

    Trainer(
        model=model,
        args=TrainingArguments(
            output_dir=args.out,
            num_train_epochs=args.epochs,
            per_device_train_batch_size=args.batch,
            gradient_accumulation_steps=args.accum,
            learning_rate=args.lr,
            lr_scheduler_type="cosine",
            warmup_ratio=0.03,
            logging_steps=10,
            save_strategy="epoch",
            save_total_limit=2,
            bf16=True,
            gradient_checkpointing=True,
            optim="paged_adamw_8bit",
            report_to="none",
        ),
        train_dataset=JudgeDataset(train_rows, tok),
        data_collator=PadCollator(tok.pad_token_id),
    ).train()

    model.save_pretrained(args.out)
    tok.save_pretrained(args.out)
    print(f"\n어댑터 저장 -> {args.out}")
    print("다음: python 03_eval.py --adapter", args.out)


if __name__ == "__main__":
    main()
