# 판정 모델 파이프라인

인터랙티브 스토리 엔진의 '판정 모듈'을 소형 모델로 자체화하는 최소 파이프라인.
서술은 하지 않는다. 점원의 행동을 읽고 플래그 변화만 JSON으로 뱉는다.

```
spec.py           상태 공간 · 전이함수 · 프롬프트 템플릿  (단일 정의)
01_generate.py    교사 모델로 합성 데이터 생성  (교사 교체 가능)
02_train.py       LoRA 파인튜닝  (CUDA/MPS/CPU 자동 감지)
03_eval.py        정확도 측정 + 스키마 강제 디코딩
04_serve.py       추론 서버 (판정 + 서술 중계)
ui.html           개발용 UI — 플래그·가드가 전부 보인다
play.html         플레이어용 UI — 이름 입력, 캐릭터 표정, 대화 박스
DEPLOY.md         공개 배포 안내 (터널, 호스팅)
ASSETS.md         이미지 제작 사양 (비율, 표정 정합)
```

## 권장 순서: 맥에서 검증 → 데스크톱에서 본학습

맥에서 작은 모델로 전체를 돌려 시행착오를 먼저 걷어내고, 같은 스크립트를
NVIDIA GPU에서 본학습에 쓴다. `02_train.py`가 장치를 자동 감지하므로
코드를 고칠 필요가 없다.

| | 맥 (MPS) | 데스크톱 (CUDA) |
|---|---|---|
| 4비트 양자화 | 꺼짐 — `bitsandbytes`가 CUDA 전용 | 켜짐 |
| dtype | float32 | bfloat16 |
| optimizer | `adamw_torch` | `paged_adamw_8bit` |
| 권장 모델 | Qwen2.5-0.5B-Instruct | Kanana 2.1B |
| guided decoding | 불가 (`--backend hf`) | 가능 (vLLM) |

16GB 맥에서 2B를 float32로 올리면 스왑으로 빠진다. 검증은 0.5B로 한다.

## 0. 데이터 생성 (맥)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install google-genai
export GEMINI_API_KEY=...          # 대문자. 소문자는 인식 안 됨
python spec.py                     # 상태 공간 확인
python 01_generate.py --limit-cells 20 --per-cell 8 --out data/probe.jsonl
```

버림 비율이 20%를 넘으면 전량 생성 전에 교사 프롬프트를 고친다.
사유별 처방은 스크립트가 출력한다. 괜찮으면 전량:

```bash
python 01_generate.py --per-cell 10 --out data/raw.jsonl
python 01_generate.py --per-cell 10 --out data/raw.jsonl --resume   # 한도로 끊겼을 때
```

생성 후 **플래그별 전환 샘플 수**를 반드시 확인한다. 특정 플래그의
`false->true` 샘플이 적으면 모델은 "그 플래그는 안 바뀐다"를 학습한다.

```bash
python -c "
import json,collections
rows=[json.loads(l) for l in open('data/raw.jsonl')]
print(collections.Counter(r['kind'] for r in rows))
flip=collections.Counter()
for r in rows:
    for f in ('사연','제목','재고'):
        if r['label']['set'][f] and not r['state']['flags'][f]: flip[f]+=1
print(flip)
"
```

## 1. 맥에서 흐름 확인 (수 분)

```bash
pip install torch transformers peft accelerate
python 02_train.py --data data/raw.jsonl --out out/smoke \
    --model Qwen/Qwen2.5-0.5B-Instruct --smoke
python 03_eval.py --adapter out/smoke --backend hf --limit 40
```

`--smoke`는 200건 1epoch만 돈다. 성능이 아니라 **끝까지 도는지**를 본다.
`--base`는 생략해도 된다 — `02_train.py`가 `base_model.txt`에 적어둔다.

## 2. 맥에서 제대로 (1~2시간)

```bash
python 02_train.py --data data/raw.jsonl --out out/judge-small \
    --model Qwen/Qwen2.5-0.5B-Instruct
python 03_eval.py --adapter out/judge-small --backend hf
```

## 3. 데스크톱에서 본학습

옮길 파일: `spec.py` `02_train.py` `03_eval.py` `data/raw.jsonl`

```bash
pip install torch transformers peft accelerate bitsandbytes
python 02_train.py --data data/raw.jsonl --out out/judge-lora --batch 8 --accum 2
pip install vllm
python 03_eval.py --adapter out/judge-lora                  # 스키마 강제 켜짐
python 03_eval.py --adapter out/judge-lora --no-guided      # 형식 학습 정도 비교
```

RTX 3080 Ti(12GB)면 기본값으로 충분하다. 4253건 x 3epoch 기준 40~70분.
`CUDA out of memory`가 나면 `--batch 4 --accum 4`로 내린다.
윈도우면 WSL2(Ubuntu)에서 할 것 — `bitsandbytes`가 윈도우 네이티브에서 말썽이 많다.

## 각 단계에서 볼 것

**생성 — 버림 비율.** 교사 출력을 스키마·단조성·유형정합성 세 겹으로 거른다.
20%를 넘으면 데이터가 아니라 교사 프롬프트가 문제다.

**학습 — `LoRA 타깃`과 `trainable params`.** 타깃 이름은 모델에서 직접 읽으므로
하드코딩 불일치로 멈추지 않는다. trainable이 전체의 1% 미만이면 정상.
loss는 2~3에서 시작해 0.3~0.8로 떨어지면 정상이고, 0.05 밑으로 가면 외우는 중이니
epoch을 줄인다.

**평가 — `false->true` 열만 보라.** 전체 정확도는 '변화 없음' 샘플이 다수라
그냥 높게 나온다. 플래그가 서야 할 때 세웠는지가 실제 판정 능력이다.

## 설계상 중요한 두 가지

**프롬프트는 `spec.py`에만 있다.** 생성·학습·추론이 전부 `build_prompt()`를 쓴다.
템플릿이 흩어지면 학습과 추론 입력이 미세하게 달라지는 train/serve skew가 생기고,
이게 소형 모델 파인튜닝에서 성능이 안 나오는 가장 흔한 원인이다.

**프롬프트 구간은 loss에서 뺀다.** `JudgeDataset`에서 프롬프트 토큰을 `-100`으로
마스킹한다. 이걸 빼먹으면 모델이 긴 세계 설정을 외우는 데 용량을 다 쓰고
정작 판정은 못 배운다.

## 모델 메모

- `kakaocorp/kanana-nano-2.1b-instruct` — Apache 2.0, 상업 이용 자유.
  받기 전에 Hugging Face에서 실제 저장소 id와 라이선스를 확인할 것.
- `Qwen/Qwen2.5-0.5B-Instruct` — 맥 검증용. 라이선스는 버전별로 확인.
- EXAONE은 성능이 좋지만 비상업 라이선스라 서비스에 쓸 수 없다.
- instruct(chat) 버전이어야 한다. base 모델은 `chat_template`이 없어 멈춘다.

## 4. UI 로 확인

```bash
pip install fastapi uvicorn
export GEMINI_API_KEY=...        # 서술용. 없으면 고정 문구로 대체된다
python 04_serve.py --adapter out/smoke
```

서버가 뜨면 `ui.html` 을 브라우저로 열면 된다(더블클릭으로 충분).
좌상단 표시등이 초록이면 연결된 것이다.

서버는 모델 출력을 그대로 내보내지 않고 세 겹으로 조인다.

| 가드 | 하는 일 |
|---|---|
| 스키마 검증 | 형식이 깨지면 '변화 없음'으로 떨어뜨린다 |
| 단조성 강제 | `false -> true` 만 허용. 되돌림은 무시 |
| 제목 교차검증 | 발화에 실제 제목 문자열이 없으면 제목 플래그를 끈다 |

세 번째가 특히 중요하다. 제목은 전이 함수에서 종료에 직결되므로, 오탐이 나면
유저가 아무것도 못 찾았는데 '찾았습니다' 엔딩이 나온다. 문자열 매칭으로
판정 가능한 일을 모델에게 맡길 이유가 없다.

가드가 발동하면 UI 의 '판정 근거' 아래 보라색으로 표시된다.
모델이 무엇을 틀렸고 코드가 무엇을 막았는지가 화면에서 보인다.

판정 품질이 나쁜 어댑터로도 배선은 확인할 수 있다. 어댑터만 나중에 교체하면 된다.

## 아직 안 들어간 것

- **선호 최적화(DPO).** SFT는 "틀리지 않는 판정"까지. 경계 사례 품질을 올리려면
  실서비스 로그에서 오판을 모아 선호 쌍을 만들어야 한다.
- **서술 모델.** 별도 파이프라인. 대본·소설을 `{상황+입력} -> {응답}` 쌍으로
  재구성하는 가공이 먼저 필요하다.
