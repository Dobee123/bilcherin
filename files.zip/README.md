# 판정 모델 파이프라인

인터랙티브 스토리 엔진의 '판정 모듈'을 2B급 소형 모델로 자체화하는 최소 파이프라인.
서술은 하지 않는다. 점원의 행동을 읽고 플래그 변화만 JSON으로 뱉는다.

```
spec.py           상태 공간 · 전이함수 · 프롬프트 템플릿  (단일 정의)
01_generate.py    교사 모델로 합성 데이터 생성  (교사 교체 가능)
02_train.py       QLoRA 파인튜닝
03_eval.py        스키마 강제 디코딩 + 정확도 측정
```

## 왜 판정부터인가

| | 서술 모델 | **판정 모델 (이 저장소)** |
|---|---|---|
| 품질 민감도 | 높음 — 제품 그 자체 | 낮음 — 맞거나 틀리거나 |
| 크기 | 7~14B | 2B |
| 형식 보장 | 불가 | guided decoding으로 100% |
| 자체화 리스크 | 큼 | 거의 없음 |

호출 빈도가 높아 비용 절감 효과는 큰데 리스크는 낮다. 서술은 당분간 API로 두고
볼륨이 붙은 뒤에 같은 순서로 내린다.

## 0. 준비

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install google-genai
```

키 발급: https://aistudio.google.com/apikey — 카드 등록 불필요.

```bash
export GEMINI_API_KEY=...
python3 spec.py        # 비종료 상태 75개 x 행동 8유형 = 600칸
```

## 1. 점검 — 20칸만

```bash
python3 01_generate.py --limit-cells 20 --per-cell 8 --out data/probe.jsonl
```

**버림 비율이 20%를 넘으면 여기서 멈추고 교사 프롬프트를 고친다.**
넘긴 채로 전량 생성하면 쓰레기만 쌓인다. 사유별 처방은 스크립트가 출력한다.

눈으로도 확인한다. 검증 코드를 통과했다고 정답은 아니다.

```bash
head -3 data/probe.jsonl | python3 -c "import json,sys;[print(json.dumps(json.loads(l),ensure_ascii=False,indent=2)) for l in sys.stdin]"
```

## 2. 전량 생성

```bash
python3 01_generate.py --per-cell 10 --out data/raw.jsonl
```

무료 티어는 **토큰이 아니라 요청 수가 병목**이다. 칸 하나에 요청 하나가 나가므로
600칸 = 600요청. `--per-cell`을 키워 요청당 수확량을 올리는 쪽이 유리하다.
다만 키울수록 교사가 말만 바꾼 중복을 내놓으니 `버림·중복` 수치를 보고 조절한다.

일일 한도에 걸려 끊기면 다음 날 이어간다. 채운 칸은 건너뛴다.

```bash
python3 01_generate.py --per-cell 10 --out data/raw.jsonl --resume
```

## 3~4. 학습과 평가 — NVIDIA GPU에서

```bash
python3 02_train.py --data data/raw.jsonl --out out/judge-lora
python3 03_eval.py --adapter out/judge-lora
python3 03_eval.py --adapter out/judge-lora --no-guided   # 형식 학습 정도 비교
```

**맥에서는 02번이 돌지 않는다.** `bitsandbytes` 4비트 양자화가 CUDA 전용이다.
RunPod·Vast.ai 등에서 24GB GPU를 빌려 `data/raw.jsonl`만 올리면 된다.
GPU 이미지는 Python 3.11을 고르는 쪽이 속 편하다 — torch 생태계가 3.13 휠을
늦게 내놓는다. 3천 건 x 3epoch 기준 30~60분.

## 교사 모델 선택

```bash
--teacher gemini      # 기본. 무료, 카드 불필요
--teacher anthropic   # 유료. 품질 재생성용
--teacher openai      # 데이터 공유 옵트인 시 무료 (자격 심사 있음)
--teacher ollama      # 완전 무료, 로컬. 맥에서 가능
```

무료 티어 조건은 자주 바뀐다. 2026년 9월 기준 Gemini는 Flash 계열이 하루 20요청,
Flash-Lite가 500요청 수준이고 구글은 공식 문서에서 무료 티어 표를 내렸다.
현재 한도는 429 응답의 `quotaValue` 필드가 알려준다. 모델명이 거부되면
(`limit: 0`) 그 모델이 무료 티어에 없는 것이므로 `--model`로 바꾼다.

Ollama 8B급은 한국어 지시 이행이 약해 버림 비율이 40~60%까지 오른다.
파이프라인 점검용으로만 쓰는 게 맞다.

**교사 품질이 학생 모델 성능의 상한이다.** 증류는 교사를 넘지 못한다.
무료로 파이프라인을 세우고, `false->true` 정확도가 낮게 나오면 상위 모델로
재생성하는 순서를 권한다.

## 각 단계에서 볼 것

**1단계 — 버림 비율.** 교사 출력을 스키마·단조성·유형정합성 세 겹으로 거른다.
20%를 넘으면 데이터가 아니라 교사 프롬프트가 문제다.

**3단계 — `trainable params`.** LoRA rank 16이면 전체의 1% 미만이어야 정상.
이보다 크면 `target_modules`가 잘못 걸린 것.

**4단계 — `false->true` 열만 보라.** 전체 정확도는 '변화 없음' 샘플이 다수라
그냥 높게 나온다. 플래그가 서야 할 때 세웠는지가 실제 판정 능력이다.
이 열이 낮으면 해당 행동 유형(`검색`, `특정`)의 데이터를 늘린다.

## 설계상 중요한 두 가지

**프롬프트는 `spec.py`에만 있다.** 생성·학습·추론이 전부 `build_prompt()`를 쓴다.
템플릿이 흩어지면 학습과 추론 입력이 미세하게 달라지는 train/serve skew가 생기고,
이게 소형 모델 파인튜닝에서 성능이 안 나오는 가장 흔한 원인이다.

**프롬프트 구간은 loss에서 뺀다.** `02_train.py`의 `JudgeDataset`에서 프롬프트
토큰을 `-100`으로 마스킹한다. 이걸 빼먹으면 2B 모델이 긴 세계 설정을 외우는 데
용량을 다 쓰고 정작 판정은 못 배운다.

## 모델 선택 메모

- 기본값 `kakaocorp/kanana-nano-2.1b-instruct` — **Apache 2.0**, 상업 이용 자유.
  받기 전에 Hugging Face에서 실제 저장소 id와 라이선스 파일을 확인할 것.
- Qwen 계열로 바꾸려면 `--model`, `--base`만 교체. 라이선스는 버전마다 다르다.
- EXAONE은 성능이 좋지만 비상업 라이선스라 서비스에 쓸 수 없다.

## 아직 안 들어간 것

- **선호 최적화(DPO).** SFT는 "틀리지 않는 판정"까지. 경계 사례 품질을 올리려면
  실서비스 로그에서 오판 사례를 모아 선호 쌍을 만들어야 한다.
- **실서비스 로그 수집.** 합성 데이터는 부트스트랩용이다. 진짜 성능은 실제 유저
  입력으로 갈아끼우면서 올라간다.
- **서술 모델.** 별도 파이프라인. 대본·소설을 `{상황+입력} -> {응답}` 쌍으로
  재구성하는 가공이 먼저 필요하다.
