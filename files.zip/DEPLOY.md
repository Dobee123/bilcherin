# 다른 사람에게 보여주기

## 먼저: GitHub 만으로는 안 된다

GitHub Pages 는 **정적 파일만** 서빙한다. 판정 모델은 파이썬 프로세스로 돌아야
하므로 Pages 에 올릴 수 없다. `play.html` 만 올리면 방문자의 브라우저가
`127.0.0.1:8000` 즉 **방문자 자신의 컴퓨터**를 찾다가 실패한다.

| 역할 | 어디에 |
|---|---|
| 코드 보관·협업 | GitHub |
| `play.html` 서빙 | GitHub Pages 또는 그냥 파일 전달 |
| **판정 서버** | 내 PC + 터널, 또는 GPU 호스팅 |

## 가장 빠른 길 — 터널

내 PC 에서 서버를 돌리고 임시 공개 주소를 받는다. 무료고, PC 를 켜둬야 한다.

```bash
# 1) 서버 띄우기 (--host 0.0.0.0 중요)
python 04_serve.py --adapter out/judge-lora --host 0.0.0.0 --port 8000

# 2) 다른 터미널에서 터널
brew install cloudflared
cloudflared tunnel --url http://localhost:8000
```

`https://something-random.trycloudflare.com` 같은 주소가 나온다. 그러면
`play.html` 을 열 때 주소 뒤에 붙여주면 된다.

```
play.html?api=https://something-random.trycloudflare.com
```

`play.html` 자체도 공유해야 하므로, 로컬에서 간단히 띄우거나

```bash
python -m http.server 5500
# http://localhost:5500/play.html?api=https://...
```

GitHub Pages 에 `play.html` 과 `assets/` 만 올리고 `?api=` 로 서버를 가리켜도 된다.

### 보안 메모

터널 주소를 아는 사람은 누구나 `/turn` 을 호출할 수 있다. 공개 전에
`04_serve.py` 의 CORS `allow_origins=["*"]` 를 실제 페이지 주소로 좁히고,
오래 열어둘 거면 간단한 토큰 검사라도 붙이는 게 좋다.

## 상시 공개가 필요해지면

PC 를 끄면 끊기므로 데모 이상으로 쓰려면 호스팅이 필요하다.

- **Hugging Face Spaces** — 무료 CPU 티어 있음. 2B 모델은 CPU 로도 느리게나마 돈다.
  GPU 티어는 유료.
- **Modal / RunPod Serverless** — 호출당 과금. 안 쓰면 비용 0 에 가깝다.
  콜드 스타트가 수십 초 걸린다.
- **상시 GPU 인스턴스** — 가장 빠르지만 월 고정비가 나간다.

서술 모델(Gemini)은 어차피 외부 API 라 어디서 돌든 상관없다. 옮길 건 판정 모델뿐이다.

## 이미지 준비

`play.html` 과 같은 폴더에 `assets/` 를 만들고 아래 파일을 넣는다.
**없어도 돌아간다** — 없는 표정은 자리표시자로 표시되고, 나중에 파일만
넣으면 코드 수정 없이 자동으로 붙는다.

```
assets/
  neutral.png    평범
  happy.png      기쁨
  sad.png        슬픔
  angry.png      분노
  bg.png         배경 (선택)
```

- 세로형 3:4 비율, 배경 투명 PNG, 긴 변 1000px 안팎이면 충분하다.
- 네 장은 **같은 구도·같은 크기**여야 한다. 표정만 다르고 위치가 어긋나면
  전환할 때 캐릭터가 튄다.
- 어두운 화면 위에 올라가므로 외곽선이 너무 어두우면 묻힌다.

### Live2D 를 원한다면

지금 구현은 PNG 네 장 + CSS 호흡 애니메이션이다. 진짜 Live2D 는 Cubism
SDK 와 `.moc3` 모델 파일이 필요하고 제작 난도가 다르다. 먼저 PNG 로
흐름을 확정한 뒤 교체하는 편이 낫다 — 감정 전환 로직은 그대로 쓸 수 있다.

## 감정은 어디서 오나

서술 모델이 장면을 쓰면서 함께 고른다. 장면을 쓴 쪽이 그 장면의 정서를
가장 잘 알기 때문이다. 판정 모델은 관여하지 않는다 — 학습 데이터에 감정
라벨이 없으므로 물어봐야 답할 수 없다.

서술 모델이 감정을 주지 않거나 JSON 이 깨지면 코드가 상태에서 유도한다
(`Narrator.fallback_emotion`). 이 경우 `notes` 에 `감정 유도 — 모델 미제공`
이 남는다.

## 이름은 서술 모델에만 전달된다

`playerName` 은 서술 프롬프트에만 들어간다. **판정 프롬프트는 건드리지 않았다.**
판정 모델은 이름 없는 프롬프트로 학습했으므로, 추론 때 프롬프트를 바꾸면
train/serve skew 가 생겨 성능이 떨어진다. 이름은 이야기의 요소지 판정의
입력이 아니다.
