"""
판정 모델의 계약(contract)을 한 곳에 모은 파일.

생성(01) / 학습(02) / 평가·추론(03)이 전부 이 파일을 import 한다.
프롬프트 템플릿이 세 군데에 흩어지면 학습과 추론이 달라지는
train/serve skew가 생기고, 그게 소형 모델 파인튜닝에서 성능이
안 나오는 가장 흔한 원인이다. 템플릿은 반드시 여기 하나만 둔다.
"""

from __future__ import annotations
import json
from itertools import product
from typing import Any

# ---------------------------------------------------------------------------
# 상태 공간
# ---------------------------------------------------------------------------

PHASES = ["도입", "탐색", "특정"]
FLAGS = ["사연", "제목", "재고"]

TRUST_MIN, TRUST_MAX = 0, 3
TURNS_START = 12

FLAG_RULES = {
    "사연": "손님이 할머니 이야기를 털어놓았으면 true",
    "제목": (
        "점원이 『고래가 사는 우물』이라는 책을 특정해냈으면 true. "
        "제목을 말하거나 단말기 검색으로 찾아낸 경우. 막연한 추측은 false"
    ),
    "재고": "점원이 실제로 서가나 단말기에서 재고를 확인했고 그 결과를 확인했으면 true",
}

ENDINGS = {
    "찾았습니다": "제목 and 재고",
    "그냥 가볼게요": "trust <= 0",
    "닫을 시간입니다": "turns_left <= 0",
}

WORLD = """심야 서점 '오후 열한시'. 폐점 10분 전, 밖에는 비.
플레이어는 혼자 가게를 지키는 점원이다.
손님: 30대 후반 여성. 비에 젖은 얇은 코트. 우산이 없다.
손님이 찾는 책(점원에게 비공개): 어릴 때 할머니가 읽어주던 그림책.
  표지에 파란 고래가 있었고, 고래가 우물 속에 산다는 이야기. 제목은 『고래가 사는 우물』.
  손님은 제목을 기억하지 못한다.
손님의 사연(비공개): 할머니가 지난달 돌아가셨다. 유품을 정리하다 그 책이 없어진 걸 알았다.
손님의 성격: 처음엔 말을 아끼고 둘러댄다. 다그치거나 폐점을 들먹이면 마음을 닫는다.
  귀 기울이면 조금씩 털어놓는다."""


# ---------------------------------------------------------------------------
# 전이 함수 — 종료를 결정하는 유일한 주체 (모델이 아니다)
# ---------------------------------------------------------------------------

def transition(phase: str, flags: dict[str, bool], trust: int, turn: int,
               turns_left: int) -> tuple[str | None, str]:
    """(ending, phase)를 돌려준다. ending이 None이 아니면 이야기는 끝났다."""
    if flags["제목"] and flags["재고"]:
        return "찾았습니다", phase
    if trust <= 0:
        return "그냥 가볼게요", phase
    if turns_left <= 0:
        return "닫을 시간입니다", phase
    if flags["제목"]:
        return None, "특정"
    if turn >= 1:
        return None, "탐색"
    return None, "도입"


# ---------------------------------------------------------------------------
# 출력 스키마 — guided decoding에 그대로 먹인다
# ---------------------------------------------------------------------------

OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "set": {
            "type": "object",
            "properties": {f: {"type": "boolean"} for f in FLAGS},
            "required": FLAGS,
            "additionalProperties": False,
        },
        "trustDelta": {"type": "integer", "minimum": -1, "maximum": 1},
        "why": {"type": "string", "maxLength": 120},
    },
    "required": ["set", "trustDelta", "why"],
    "additionalProperties": False,
}


# ---------------------------------------------------------------------------
# 프롬프트 — 생성/학습/추론이 모두 이 함수를 쓴다
# ---------------------------------------------------------------------------

INSTRUCTION = f"""너는 인터랙티브 소설 엔진의 '판정 모듈'이다.
장면을 쓰지 말고, 점원의 행동을 읽어 플래그 변화만 보고하라.
이야기를 끝낼 권한은 너에게 없다.

[세계 설정]
{WORLD}

[플래그 판정 규칙]
""" + "\n".join(f"- {k}: {v}" for k, v in FLAG_RULES.items()) + """
- trustDelta: 공감하거나 귀 기울이면 +1, 중립이면 0, 재촉·무시·빈정대거나 폐점을 들먹이면 -1
- 이미 true인 플래그는 true로 유지하라. 절대 false로 되돌리지 마라.

[출력]
JSON 하나만. {"set":{"사연":bool,"제목":bool,"재고":bool},"trustDelta":int,"why":"한 줄 근거"}"""


def build_prompt(state: dict, history: list[str], action: str) -> str:
    """판정 모델에 들어갈 user 메시지 본문."""
    hist = "\n".join(history[-6:]) if history else "(아직 없음)"
    flags = state["flags"]
    return f"""{INSTRUCTION}

[현재 상태]
단계: {state['phase']}
플래그: 사연={str(flags['사연']).lower()}, 제목={str(flags['제목']).lower()}, 재고={str(flags['재고']).lower()}
신뢰: {state['trust']}/{TRUST_MAX}
남은 턴: {state['turns_left']}

[지금까지]
{hist}

[점원의 행동]
{action}"""


def build_target(label: dict) -> str:
    """정답 라벨을 학습 타깃 문자열로. 키 순서를 고정해야 학습이 안정적이다."""
    return json.dumps(
        {
            "set": {f: bool(label["set"][f]) for f in FLAGS},
            "trustDelta": int(label["trustDelta"]),
            "why": str(label["why"]),
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


# ---------------------------------------------------------------------------
# 비종료 상태 열거 — 판정 모델이 호출되는 상태는 전부 비종료 상태뿐이다
# ---------------------------------------------------------------------------

def enumerate_states() -> list[dict]:
    out = []
    for phase, combo, trust, turns_left in product(
        PHASES,
        product([False, True], repeat=len(FLAGS)),
        range(TRUST_MIN + 1, TRUST_MAX + 1),   # trust 0 이면 이미 종료
        [1, 3, 6, 10],                          # 남은 턴 대표값
    ):
        flags = dict(zip(FLAGS, combo))

        # 종료 상태는 제외 (판정 모델이 호출되지 않는다)
        if flags["제목"] and flags["재고"]:
            continue
        # 단계와 플래그의 정합성
        if phase == "특정" and not flags["제목"]:
            continue
        if phase == "탐색" and flags["제목"]:
            continue
        if phase == "도입" and (any(combo) or turns_left != 10):
            continue

        out.append({
            "phase": phase,
            "flags": flags,
            "trust": trust,
            "turn": 0 if phase == "도입" else TURNS_START - turns_left,
            "turns_left": turns_left,
        })
    return out


# 점원 행동의 유형. 유형을 명시해야 데이터가 한쪽으로 쏠리지 않는다.
ACTION_KINDS = {
    "공감":   "손님의 말을 받아주고 귀 기울인다. 서두르지 않는다.",
    "재촉":   "용건을 재촉하거나 폐점 시간을 들먹인다.",
    "질문":   "책의 생김새나 기억을 구체적으로 묻는다.",
    "검색":   "단말기나 서가에서 실제로 찾아보는 행동을 한다.",
    "추측":   "제목을 확신 없이 넘겨짚는다. (제목 플래그는 false여야 한다)",
    "특정":   "검색이나 추론 끝에 『고래가 사는 우물』을 정확히 짚어낸다.",
    "무관":   "책과 상관없는 말을 한다. 날씨, 잡담, 혼잣말.",
    "무시":   "손님을 응대하지 않거나 빈정댄다.",
}


def validate(label: Any) -> bool:
    """모델/교사 출력이 스키마를 만족하는지 가볍게 검사."""
    if not isinstance(label, dict):
        return False
    if set(label) != {"set", "trustDelta", "why"}:
        return False
    s = label["set"]
    if not isinstance(s, dict) or set(s) != set(FLAGS):
        return False
    if not all(isinstance(s[f], bool) for f in FLAGS):
        return False
    if not isinstance(label["trustDelta"], int) or label["trustDelta"] not in (-1, 0, 1):
        return False
    return isinstance(label["why"], str) and 0 < len(label["why"]) <= 120


def monotonic_ok(before: dict[str, bool], after: dict[str, bool]) -> bool:
    """플래그는 false -> true 단방향. 되돌린 라벨은 버린다."""
    return all(not (before[f] and not after[f]) for f in FLAGS)


if __name__ == "__main__":
    states = enumerate_states()
    print(f"비종료 상태 {len(states)}개")
    print(f"행동 유형 {len(ACTION_KINDS)}개")
    print(f"조합 상한 {len(states) * len(ACTION_KINDS)}개")
